import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Coffee, Check, MapPin, Clock } from "lucide-react";

interface CartItem {
  menuItem: {
    id: string;
    name: string;
    price: number;
  };
  quantity: number;
  notes?: string;
}

export default function Checkout() {
  const navigate = useNavigate();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [sessionInfo, setSessionInfo] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderNumber, setOrderNumber] = useState("");
  const [specialNotes, setSpecialNotes] = useState("");

  useEffect(() => {
    const session = sessionStorage.getItem("orderSession");
    const cartData = sessionStorage.getItem("cart");

    if (!session || !cartData) {
      navigate("/scanner");
      return;
    }

    setSessionInfo(JSON.parse(session));
    setCart(JSON.parse(cartData));
  }, [navigate]);

  const totalPrice = cart.reduce(
    (sum, item) => sum + item.menuItem.price * item.quantity,
    0
  );

  const handlePlaceOrder = () => {
    setIsProcessing(true);

    // Simulate order processing
    setTimeout(() => {
      const orderId = "OM" + Math.random().toString(36).substr(2, 7).toUpperCase();
      setOrderNumber(orderId);

      // Create order object
      const order = {
        orderId,
        sessionId: sessionInfo.sessionId,
        type: sessionInfo.type,
        table: sessionInfo.table || null,
        customerName: sessionInfo.name,
        items: cart,
        specialNotes,
        totalPrice,
        status: "pending",
        createdAt: new Date().toISOString(),
        estimatedTime: new Date(Date.now() + 15 * 60000).toISOString(),
      };

      // Save order to localStorage (for kitchen display system to read)
      const allOrders = JSON.parse(localStorage.getItem("orders") || "[]");
      allOrders.push(order);
      localStorage.setItem("orders", JSON.stringify(allOrders));

      // Also notify the kitchen display system
      window.dispatchEvent(
        new CustomEvent("orderPlaced", { detail: order })
      );

      setOrderPlaced(true);
      setIsProcessing(false);

      // Clear session after 30 seconds
      setTimeout(() => {
        sessionStorage.removeItem("orderSession");
        sessionStorage.removeItem("cart");
      }, 30000);
    }, 1500);
  };

  if (!sessionInfo) {
    return null;
  }

  if (orderPlaced) {
    return (
      <div className="min-h-screen bg-background">
        {/* Navigation */}
        <nav className="sticky top-0 z-50 bg-card shadow-md">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <Coffee className="w-8 h-8 text-primary" />
              <span className="font-display text-2xl font-bold text-primary">
                Rumah Kopi Oma
              </span>
            </Link>
          </div>
        </nav>

        {/* Order Confirmation */}
        <div className="container mx-auto px-3 sm:px-4 py-8 sm:py-20">
          <div className="max-w-2xl mx-auto">
            <div className="bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl p-6 sm:p-12 text-center border-2 border-primary mb-8">
              <div className="flex justify-center mb-6">
                <div className="bg-primary text-primary-foreground rounded-full p-4">
                  <Check className="w-12 h-12" />
                </div>
              </div>
              <h1 className="font-display text-3xl sm:text-4xl font-bold text-primary mb-4">
                Pesanan Dikonfirmasi!
              </h1>
              <p className="text-base sm:text-xl text-foreground/80 font-body mb-8">
                Terima kasih telah memesan di Rumah Kopi Oma
              </p>

              {/* Order Number */}
              <div className="bg-card rounded-xl p-6 sm:p-8 shadow-lg mb-8 border border-border/50">
                <p className="text-xs sm:text-sm text-foreground/60 font-body mb-2">
                  Nomor Pesanan
                </p>
                <p className="font-display text-4xl sm:text-5xl font-bold text-primary">
                  {orderNumber}
                </p>
              </div>

              {/* Order Details */}
              <div className="bg-card rounded-xl p-6 sm:p-8 text-left mb-8 border border-border/50">
                <h3 className="font-display text-xl sm:text-2xl font-bold text-primary mb-6">
                  Detail Pesanan
                </h3>

                {/* Customer Info */}
                <div className="space-y-3 mb-6 pb-6 border-b border-border">
                  <p className="font-body">
                    <span className="text-foreground/60">Nama:</span>{" "}
                    <span className="font-semibold text-primary">
                      {sessionInfo.name}
                    </span>
                  </p>
                  {sessionInfo.type === "dine-in" && (
                    <p className="font-body">
                      <span className="text-foreground/60">Meja:</span>{" "}
                      <span className="font-semibold text-primary">
                        {sessionInfo.table}
                      </span>
                    </p>
                  )}
                  {sessionInfo.type === "pickup" && (
                    <p className="font-body">
                      <span className="text-foreground/60">Tipe:</span>{" "}
                      <span className="font-semibold text-primary">
                        Bawa Pulang
                      </span>
                    </p>
                  )}
                </div>

                {/* Items */}
                <div className="space-y-3 mb-6 pb-6 border-b border-border">
                  {cart.map((item) => (
                    <div
                      key={item.menuItem.id}
                      className="flex justify-between font-body"
                    >
                      <span>
                        {item.menuItem.name} x {item.quantity}
                      </span>
                      <span className="font-semibold">
                        Rp{" "}
                        {(
                          item.menuItem.price * item.quantity
                        ).toLocaleString("id-ID")}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Total */}
                <div className="flex justify-between items-center">
                  <span className="font-display text-xl font-bold text-foreground">
                    Total
                  </span>
                  <span className="font-display text-3xl font-bold text-primary">
                    Rp {totalPrice.toLocaleString("id-ID")}
                  </span>
                </div>
              </div>

              {/* Estimated Time */}
              <div className="bg-secondary/30 rounded-xl p-6 mb-8 border border-border/50">
                <div className="flex items-center justify-center gap-3 font-body">
                  <Clock className="w-5 h-5 text-primary" />
                  <span>
                    <strong className="text-primary">Estimasi waktu:</strong> 15
                    menit
                  </span>
                </div>
              </div>

              {/* Instructions */}
              {sessionInfo.type === "dine-in" ? (
                <div className="bg-primary/10 rounded-xl p-6 mb-8 border border-primary/30">
                  <p className="font-body text-foreground">
                    📍 Pesanan akan diantar ke meja Anda. Mohon tunggu dengan
                    santai sambil menikmati suasana Rumah Kopi Oma!
                  </p>
                </div>
              ) : (
                <div className="bg-primary/10 rounded-xl p-6 mb-8 border border-primary/30">
                  <p className="font-body text-foreground">
                    📦 Pesanan sedang disiapkan. Silakan ke counter untuk
                    mengambil pesanan Anda.
                  </p>
                </div>
              )}

              {/* Back to Home */}
              <Link
                to="/"
                className="inline-block bg-primary text-primary-foreground px-8 py-4 rounded-lg font-semibold hover:bg-primary/90 transition-colors font-body"
              >
                Kembali ke Beranda
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card shadow-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Coffee className="w-8 h-8 text-primary" />
            <span className="font-display text-2xl font-bold text-primary">
              Rumah Kopi Oma
            </span>
          </Link>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <h1 className="font-display text-4xl font-bold text-primary mb-2">
            Konfirmasi Pesanan
          </h1>
          <p className="text-lg text-foreground/80 font-body mb-8">
            Periksa pesanan Anda sebelum mengirim
          </p>

          {/* Order Summary */}
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border/50 mb-8">
            <h2 className="font-display text-2xl font-bold text-primary mb-6">
              Ringkasan Pesanan
            </h2>

            {/* Customer Info */}
            <div className="bg-secondary/30 rounded-lg p-6 mb-6 border border-border/50">
              <p className="font-body text-sm text-foreground/60 mb-1">
                Nama Pemesan
              </p>
              <p className="font-display text-xl font-bold text-primary mb-4">
                {sessionInfo.name}
              </p>

              {sessionInfo.type === "dine-in" ? (
                <>
                  <p className="font-body text-sm text-foreground/60 mb-1">
                    Nomor Meja
                  </p>
                  <p className="font-display text-xl font-bold text-primary">
                    Meja {sessionInfo.table}
                  </p>
                </>
              ) : (
                <>
                  <p className="font-body text-sm text-foreground/60 mb-1">
                    Tipe Pesanan
                  </p>
                  <p className="font-display text-xl font-bold text-primary">
                    Bawa Pulang
                  </p>
                </>
              )}
            </div>

            {/* Items */}
            <div className="mb-6">
              <h3 className="font-semibold text-primary mb-4 font-body">
                Item yang Dipesan:
              </h3>
              <div className="space-y-3">
                {cart.map((item) => (
                  <div
                    key={item.menuItem.id}
                    className="flex justify-between items-center p-4 bg-secondary/30 rounded-lg border border-border/50"
                  >
                    <div>
                      <p className="font-semibold text-primary font-display">
                        {item.menuItem.name}
                      </p>
                      <p className="text-sm text-foreground/70 font-body">
                        Qty: {item.quantity}
                      </p>
                    </div>
                    <p className="font-bold text-primary font-body">
                      Rp{" "}
                      {(
                        item.menuItem.price * item.quantity
                      ).toLocaleString("id-ID")}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Special Notes */}
            <div className="mb-6">
              <label className="block font-semibold text-foreground mb-2 font-body">
                Catatan Khusus (Opsional)
              </label>
              <textarea
                value={specialNotes}
                onChange={(e) => setSpecialNotes(e.target.value)}
                placeholder="Contoh: Kurangi gula, tanpa es, dll..."
                className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-body resize-none"
                rows={3}
              />
            </div>

            {/* Total */}
            <div className="bg-primary/10 rounded-lg p-6 border border-primary/30 mb-8">
              <div className="flex justify-between items-center">
                <span className="font-display text-xl font-bold text-foreground">
                  Total Pembayaran
                </span>
                <span className="font-display text-3xl font-bold text-primary">
                  Rp {totalPrice.toLocaleString("id-ID")}
                </span>
              </div>
            </div>

            {/* Place Order Button */}
            <button
              onClick={handlePlaceOrder}
              disabled={isProcessing}
              className="w-full bg-primary text-primary-foreground py-4 rounded-lg font-semibold text-lg hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-body flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <>
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                      fill="none"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                  Memproses...
                </>
              ) : (
                "Kirim Pesanan"
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
