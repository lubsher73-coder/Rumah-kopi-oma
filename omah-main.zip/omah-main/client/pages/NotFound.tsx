import { useLocation } from "react-router-dom";
import { Link } from "react-router-dom";
import { Coffee } from "lucide-react";
import { useEffect } from "react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card shadow-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Coffee className="w-8 h-8 text-primary" />
            <span className="font-display text-2xl font-bold text-primary">
              Rumah Kopi Oma
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link
              to="/"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Home
            </Link>
            <Link
              to="/menu"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Menu
            </Link>
            <Link
              to="/about"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              About
            </Link>
            <Link
              to="/contact"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Contact
            </Link>
          </div>
          <button className="md:hidden">
            <svg
              className="w-6 h-6 text-foreground"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>
        </div>
      </nav>

      {/* 404 Content */}
      <div className="flex items-center justify-center min-h-[calc(100vh-80px)]">
        <div className="text-center px-4">
          <h1 className="font-display text-8xl font-bold text-accent mb-4">
            404
          </h1>
          <p className="font-display text-4xl font-bold text-primary mb-4">
            Halaman Tidak Ditemukan
          </p>
          <p className="text-xl text-foreground/80 mb-8 max-w-md mx-auto font-body">
            Maaf, halaman yang Anda cari tidak ada. Mungkin Anda perlu mencoba mencari halaman lain.
          </p>
          <Link
            to="/"
            className="inline-block bg-primary text-primary-foreground px-8 py-4 rounded-lg font-semibold text-lg hover:bg-primary/90 transition-colors"
          >
            Kembali ke Home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
