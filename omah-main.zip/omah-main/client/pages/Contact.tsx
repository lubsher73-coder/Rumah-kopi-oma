import { useState } from "react";
import { Link } from "react-router-dom";
import { Coffee, MapPin, Clock, Phone, Mail, Instagram, MessageCircle } from "lucide-react";

export default function Contact() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSent(true);
    setForm({ name: "", email: "", message: "" });
  }

  return (
    <div className="min-h-screen bg-background">
      <nav className="sticky top-0 z-50 bg-card shadow-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Coffee className="w-8 h-8 text-primary" />
            <span className="font-display text-2xl font-bold text-primary">Rumah Kopi Oma</span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link to="/" className="text-foreground hover:text-primary transition-colors font-medium">Home</Link>
            <Link to="/menu" className="text-foreground hover:text-primary transition-colors font-medium">Menu</Link>
            <Link to="/about" className="text-foreground hover:text-primary transition-colors font-medium">About</Link>
            <Link to="/contact" className="text-primary font-bold">Contact</Link>
            <Link to="/scanner" className="bg-accent text-accent-foreground px-4 py-2 rounded-lg font-semibold hover:bg-accent/90 transition-colors">Pesan Sekarang</Link>
          </div>
          <button className="md:hidden p-2" onClick={() => setMobileOpen(!mobileOpen)}>
            <svg className="w-6 h-6 text-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={mobileOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
            </svg>
          </button>
        </div>
        {mobileOpen && (
          <div className="md:hidden bg-card border-t border-border px-4 py-4 space-y-3">
            <Link to="/" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileOpen(false)}>Home</Link>
            <Link to="/menu" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileOpen(false)}>Menu</Link>
            <Link to="/about" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileOpen(false)}>About</Link>
            <Link to="/contact" className="block text-primary font-bold py-2" onClick={() => setMobileOpen(false)}>Contact</Link>
            <Link to="/scanner" className="block bg-accent text-accent-foreground px-4 py-3 rounded-lg font-semibold text-center" onClick={() => setMobileOpen(false)}>Pesan Sekarang</Link>
          </div>
        )}
      </nav>

      {/* Hero */}
      <section className="bg-gradient-to-br from-secondary via-background to-background py-16 px-4">
        <div className="container mx-auto text-center max-w-2xl">
          <h1 className="font-display text-4xl md:text-6xl font-bold text-primary mb-4">Hubungi Kami</h1>
          <p className="text-lg text-foreground/70 font-body">Kami senang mendengar dari Anda. Kirim pesan atau kunjungi kami langsung!</p>
        </div>
      </section>

      <div className="container mx-auto px-4 py-14 max-w-5xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h2 className="font-display text-2xl font-bold text-primary mb-6">Informasi Kontak</h2>
              <div className="space-y-5">
                {[
                  { icon: <MapPin className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />, label: "Lokasi", value: "Jl. Subyek Merdeka No. 42\nSuburban Area, Kota" },
                  { icon: <Clock className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />, label: "Jam Buka", value: "Senin–Jumat: 07.00 – 21.00\nSabtu–Minggu: 08.00 – 22.00" },
                  { icon: <Phone className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />, label: "Telepon", value: "+62 812-3456-7890" },
                  { icon: <Mail className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />, label: "Email", value: "info@rumahkopioma.id" },
                ].map((c, i) => (
                  <div key={i} className="flex items-start gap-4 bg-card rounded-xl p-4 border border-border/50">
                    {c.icon}
                    <div>
                      <p className="font-semibold text-foreground font-body text-sm">{c.label}</p>
                      <p className="text-foreground/70 font-body text-sm whitespace-pre-line">{c.value}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-display text-xl font-bold text-primary mb-4">Ikuti Kami</h3>
              <div className="flex gap-3">
                <a href="#" className="flex items-center gap-2 bg-card border border-border/50 rounded-xl px-4 py-3 hover:bg-secondary transition-colors">
                  <Instagram className="w-5 h-5 text-accent" />
                  <span className="font-body text-sm font-medium">@rumahkopioma</span>
                </a>
                <a href="#" className="flex items-center gap-2 bg-card border border-border/50 rounded-xl px-4 py-3 hover:bg-secondary transition-colors">
                  <MessageCircle className="w-5 h-5 text-accent" />
                  <span className="font-body text-sm font-medium">WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Map placeholder */}
            <div className="bg-gradient-to-br from-secondary to-accent/10 rounded-2xl h-48 flex items-center justify-center border border-border/50 shadow-inner">
              <div className="text-center">
                <MapPin className="w-10 h-10 text-accent mx-auto mb-2 opacity-60" />
                <p className="text-foreground/50 font-body text-sm">Lihat di Google Maps</p>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-card rounded-2xl p-8 shadow-md border border-border/50">
            <h2 className="font-display text-2xl font-bold text-primary mb-6">Kirim Pesan</h2>
            {sent ? (
              <div className="text-center py-12">
                <div className="text-5xl mb-4">✅</div>
                <h3 className="font-display text-xl font-bold text-primary mb-2">Pesan Terkirim!</h3>
                <p className="text-foreground/70 font-body mb-6">Terima kasih! Kami akan membalas dalam 1×24 jam.</p>
                <button onClick={() => setSent(false)} className="bg-primary text-primary-foreground px-6 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors">
                  Kirim Pesan Lain
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-foreground/80 mb-2 font-body">Nama Lengkap</label>
                  <input
                    type="text" required
                    value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    placeholder="Nama Anda"
                    className="w-full border border-border rounded-lg px-4 py-3 bg-background text-foreground font-body focus:outline-none focus:ring-2 focus:ring-primary/40 transition"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground/80 mb-2 font-body">Alamat Email</label>
                  <input
                    type="email" required
                    value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                    placeholder="email@anda.com"
                    className="w-full border border-border rounded-lg px-4 py-3 bg-background text-foreground font-body focus:outline-none focus:ring-2 focus:ring-primary/40 transition"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground/80 mb-2 font-body">Pesan</label>
                  <textarea
                    required rows={5}
                    value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                    placeholder="Tulis pesan, pertanyaan, atau masukan Anda..."
                    className="w-full border border-border rounded-lg px-4 py-3 bg-background text-foreground font-body focus:outline-none focus:ring-2 focus:ring-primary/40 transition resize-none"
                  />
                </div>
                <button type="submit" className="w-full bg-primary text-primary-foreground py-4 rounded-lg font-semibold hover:bg-primary/90 transition-colors text-base font-body">
                  Kirim Pesan
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      <footer className="bg-card border-t border-border py-10 px-4">
        <div className="container mx-auto text-center text-foreground/60">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Coffee className="w-5 h-5 text-primary" />
            <span className="font-display text-lg font-bold text-primary">Rumah Kopi Oma</span>
          </div>
          <p className="font-body text-sm">© 2024 Rumah Kopi Oma. Semua hak dilindungi.</p>
        </div>
      </footer>
    </div>
  );
}
