import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Coffee, ShoppingBag, Phone } from "lucide-react";
import { getMenuItems, type MenuItem } from "../lib/menuData";

const CATEGORY_LABELS: Record<string, string> = {
  kopi: "Kopi",
  minuman: "Minuman",
  makanan: "Makanan",
};

export default function Menu() {
  const [selectedCategory, setSelectedCategory] = useState<"all" | "kopi" | "minuman" | "makanan">("all");
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    setMenuItems(getMenuItems());
  }, []);

  const filteredItems = selectedCategory === "all" ? menuItems : menuItems.filter((i) => i.category === selectedCategory);
  const availableItems = filteredItems.filter((i) => i.available);

  return (
    <div className="min-h-screen bg-background">
      <nav className="sticky top-0 z-50 bg-card shadow-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Coffee className="w-8 h-8 text-primary" />
            <span className="font-display text-2xl font-bold text-primary">Rumah Kopi Oma</span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link to="/" className="text-foreground hover:text-primary transition-colors font-medium">Home</Link>
            <Link to="/menu" className="text-primary font-bold">Menu</Link>
            <Link to="/about" className="text-foreground hover:text-primary transition-colors font-medium">About</Link>
            <Link to="/contact" className="text-foreground hover:text-primary transition-colors font-medium">Contact</Link>
            <Link to="/scanner" className="bg-accent text-accent-foreground px-4 py-2 rounded-lg font-semibold hover:bg-accent/90 transition-colors">
              Pesan Sekarang
            </Link>
          </div>
          <button className="md:hidden p-2" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            <svg className="w-6 h-6 text-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={mobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
            </svg>
          </button>
        </div>
        {mobileMenuOpen && (
          <div className="md:hidden bg-card border-t border-border px-4 py-4 space-y-3">
            <Link to="/" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileMenuOpen(false)}>Home</Link>
            <Link to="/menu" className="block text-primary font-bold py-2" onClick={() => setMobileMenuOpen(false)}>Menu</Link>
            <Link to="/about" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileMenuOpen(false)}>About</Link>
            <Link to="/contact" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileMenuOpen(false)}>Contact</Link>
            <Link to="/scanner" className="block bg-accent text-accent-foreground px-4 py-3 rounded-lg font-semibold text-center" onClick={() => setMobileMenuOpen(false)}>Pesan Sekarang</Link>
          </div>
        )}
      </nav>

      <section className="bg-gradient-to-br from-primary via-primary/90 to-primary/75 py-16 px-4">
        <div className="container mx-auto text-center">
          <h1 className="font-display text-4xl md:text-6xl font-bold text-primary-foreground mb-4">Menu Kami</h1>
          <p className="text-primary-foreground/80 text-lg md:text-xl max-w-2xl mx-auto font-body mb-8">
            Temukan minuman dan makanan pilihan terbaik. Dibuat dengan bahan berkualitas dan penuh cinta.
          </p>
          <Link to="/scanner" className="inline-flex items-center gap-2 bg-accent text-accent-foreground px-8 py-4 rounded-xl font-semibold text-lg hover:bg-accent/90 transition-colors shadow-lg">
            <ShoppingBag className="w-5 h-5" />
            Pesan Langsung
          </Link>
        </div>
      </section>

      <div className="sticky top-[72px] z-40 bg-background/95 backdrop-blur border-b border-border shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex gap-1 py-3 overflow-x-auto">
            {(["all", "kopi", "minuman", "makanan"] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2.5 rounded-lg font-semibold whitespace-nowrap transition-all text-sm ${
                  selectedCategory === cat ? "bg-primary text-primary-foreground shadow" : "text-foreground/70 hover:bg-secondary hover:text-foreground"
                }`}
              >
                {cat === "all" ? "Semua" : `${cat === "kopi" ? "☕" : cat === "minuman" ? "🧋" : "🥐"} ${CATEGORY_LABELS[cat]}`}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-10">
        {selectedCategory === "all" && menuItems.filter(i => i.popular && i.available).length > 0 && (
          <div className="mb-14">
            <h2 className="font-display text-3xl font-bold text-primary mb-6">⭐ Favorit Pelanggan</h2>
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {menuItems.filter(i => i.popular && i.available).map((item) => (
                <MenuCard key={item.id} item={item} featured />
              ))}
            </div>
          </div>
        )}

        {selectedCategory === "all" ? (
          (["kopi", "minuman", "makanan"] as const).map((cat) => {
            const items = menuItems.filter(i => i.category === cat && i.available);
            if (items.length === 0) return null;
            return (
              <div key={cat} className="mb-14">
                <h2 className="font-display text-3xl font-bold text-primary mb-6">
                  {cat === "kopi" ? "☕" : cat === "minuman" ? "🧋" : "🥐"} {CATEGORY_LABELS[cat]}
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                  {items.map((item) => <MenuCard key={item.id} item={item} />)}
                </div>
              </div>
            );
          })
        ) : (
          <div>
            <h2 className="font-display text-3xl font-bold text-primary mb-6">
              {selectedCategory === "kopi" ? "☕" : selectedCategory === "minuman" ? "🧋" : "🥐"} {CATEGORY_LABELS[selectedCategory]}
            </h2>
            {availableItems.length === 0 ? (
              <div className="text-center py-20 text-foreground/50">
                <p className="text-xl font-body">Tidak ada item tersedia</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                {availableItems.map((item) => <MenuCard key={item.id} item={item} />)}
              </div>
            )}
          </div>
        )}
      </div>

      <section className="bg-gradient-to-r from-primary to-primary/80 py-16 px-4">
        <div className="container mx-auto text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-primary-foreground mb-4">Siap Memesan?</h2>
          <p className="text-primary-foreground/80 text-lg mb-8 font-body">Scan QR di meja Anda atau minta barista kami membantu</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/scanner" className="inline-flex items-center justify-center gap-2 bg-accent text-accent-foreground px-8 py-4 rounded-xl font-semibold text-lg hover:bg-accent/90 transition-colors shadow-lg">
              <ShoppingBag className="w-5 h-5" />Mulai Pesan
            </Link>
            <Link to="/contact" className="inline-flex items-center justify-center gap-2 bg-primary-foreground text-primary px-8 py-4 rounded-xl font-semibold text-lg hover:bg-primary-foreground/90 transition-colors shadow-lg">
              <Phone className="w-5 h-5" />Hubungi Kami
            </Link>
          </div>
        </div>
      </section>

      <footer className="bg-card border-t border-border py-10 px-4">
        <div className="container mx-auto text-center text-foreground/60">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Coffee className="w-5 h-5 text-primary" />
            <span className="font-display text-lg font-bold text-primary">Rumah Kopi Oma</span>
          </div>
          <p className="font-body text-sm">© 2024 Rumah Kopi Oma. Semua hak dilindungi.</p>
          <p className="text-xs mt-1 font-body">Dibuat dengan ☕ dan cinta</p>
        </div>
      </footer>
    </div>
  );
}

function MenuCard({ item, featured }: { item: MenuItem; featured?: boolean }) {
  return (
    <div className={`bg-card rounded-xl border transition-all hover:shadow-lg hover:-translate-y-0.5 flex flex-col overflow-hidden ${featured ? "border-accent/40 shadow-md" : "border-border/50"}`}>
      <div className={`flex items-center justify-center text-5xl py-8 ${featured ? "bg-gradient-to-br from-accent/10 to-secondary/50" : "bg-secondary/20"}`}>
        {item.icon}
      </div>
      <div className="p-4 flex flex-col flex-1">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className="font-display text-base font-bold text-primary leading-tight">{item.name}</h3>
          {item.popular && (
            <span className="bg-accent/15 text-accent text-xs font-semibold px-2 py-0.5 rounded-full whitespace-nowrap flex-shrink-0">Favorit</span>
          )}
        </div>
        <p className="text-xs text-foreground/60 font-body mb-3 flex-1 leading-relaxed">{item.description}</p>
        <div className="flex items-center justify-between mt-auto pt-3 border-t border-border/50">
          <p className="font-bold text-primary font-display text-base">Rp {item.price.toLocaleString("id-ID")}</p>
          <Link to="/scanner" className="text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-lg font-semibold hover:bg-primary/90 transition-colors">
            Pesan
          </Link>
        </div>
      </div>
    </div>
  );
}
