import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Coffee, Plus, Trash2, Edit2, Save, X, ToggleLeft, ToggleRight, ChevronLeft, Star } from "lucide-react";
import { getMenuItems, saveMenuItems, DEFAULT_MENU_ITEMS, type MenuItem } from "../lib/menuData";

const CATEGORIES = [
  { value: "kopi", label: "☕ Kopi" },
  { value: "minuman", label: "🧋 Minuman" },
  { value: "makanan", label: "🥐 Makanan" },
];
const ICONS = ["☕", "🥛", "🧊", "🍫", "🍵", "🧋", "🥤", "🍋", "🍓", "🥐", "🍞", "🥪", "🧁", "🍌", "🧇", "🍰", "🫖", "🧃", "🍦", "🥗"];

const EMPTY_FORM: Omit<MenuItem, "id"> = {
  name: "",
  description: "",
  price: 0,
  category: "kopi",
  icon: "☕",
  available: true,
  popular: false,
};

export default function AdminMenu() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [filterCat, setFilterCat] = useState<"all" | "kopi" | "minuman" | "makanan">("all");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Omit<MenuItem, "id">>(EMPTY_FORM);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setItems(getMenuItems());
  }, []);

  function persist(updated: MenuItem[]) {
    setItems(updated);
    saveMenuItems(updated);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  function handleOpenAdd() {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setShowForm(true);
  }

  function handleOpenEdit(item: MenuItem) {
    setEditingId(item.id);
    setForm({ name: item.name, description: item.description, price: item.price, category: item.category, icon: item.icon, available: item.available, popular: item.popular ?? false });
    setShowForm(true);
  }

  function handleSave() {
    if (!form.name.trim() || !form.description.trim() || form.price <= 0) return;
    if (editingId) {
      persist(items.map(i => i.id === editingId ? { ...form, id: editingId } : i));
    } else {
      const newId = Date.now().toString();
      persist([...items, { ...form, id: newId }]);
    }
    setShowForm(false);
  }

  function handleDelete(id: string) {
    persist(items.filter(i => i.id !== id));
    setDeleteConfirm(null);
  }

  function handleToggleAvailable(id: string) {
    persist(items.map(i => i.id === id ? { ...i, available: !i.available } : i));
  }

  function handleTogglePopular(id: string) {
    persist(items.map(i => i.id === id ? { ...i, popular: !i.popular } : i));
  }

  function handleReset() {
    if (!confirm("Reset semua menu ke default? Perubahan Anda akan hilang.")) return;
    persist(DEFAULT_MENU_ITEMS);
  }

  const filtered = filterCat === "all" ? items : items.filter(i => i.category === filterCat);

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="sticky top-0 z-50 bg-card shadow-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/staff" className="p-2 hover:bg-secondary rounded-lg transition-colors">
              <ChevronLeft className="w-5 h-5 text-foreground" />
            </Link>
            <div className="flex items-center gap-2">
              <Coffee className="w-7 h-7 text-primary" />
              <span className="font-display text-xl font-bold text-primary">Kelola Menu</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {saved && (
              <span className="text-green-600 text-sm font-semibold font-body animate-pulse">✓ Tersimpan</span>
            )}
            <Link to="/menu" className="hidden sm:block text-foreground/60 hover:text-primary text-sm font-body transition-colors">
              Lihat Menu Publik →
            </Link>
            <button onClick={handleOpenAdd} className="flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2.5 rounded-lg font-semibold hover:bg-primary/90 transition-colors text-sm">
              <Plus className="w-4 h-4" />
              Tambah Menu
            </button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8 max-w-5xl">
        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Total Menu", value: items.length, color: "text-primary" },
            { label: "Tersedia", value: items.filter(i => i.available).length, color: "text-green-600" },
            { label: "Favorit", value: items.filter(i => i.popular).length, color: "text-accent" },
            { label: "Nonaktif", value: items.filter(i => !i.available).length, color: "text-foreground/50" },
          ].map((s, i) => (
            <div key={i} className="bg-card rounded-xl p-4 border border-border/50 shadow-sm text-center">
              <p className={`font-display text-3xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-foreground/60 text-xs font-body mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Filter & Reset */}
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div className="flex gap-2 flex-wrap">
            {(["all", "kopi", "minuman", "makanan"] as const).map(cat => (
              <button
                key={cat}
                onClick={() => setFilterCat(cat)}
                className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${filterCat === cat ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-secondary/70"}`}
              >
                {cat === "all" ? "Semua" : CATEGORIES.find(c => c.value === cat)?.label}
              </button>
            ))}
          </div>
          <button onClick={handleReset} className="text-xs text-foreground/50 hover:text-destructive transition-colors font-body">
            Reset ke Default
          </button>
        </div>

        {/* Menu List */}
        <div className="space-y-3">
          {filtered.length === 0 && (
            <div className="text-center py-20 text-foreground/40">
              <p className="text-xl font-body">Belum ada menu</p>
              <button onClick={handleOpenAdd} className="mt-4 text-primary font-semibold hover:underline text-sm">+ Tambah menu pertama</button>
            </div>
          )}
          {filtered.map(item => (
            <div key={item.id} className={`bg-card rounded-xl border transition-all ${item.available ? "border-border/50" : "border-border/30 opacity-60"} shadow-sm hover:shadow-md`}>
              <div className="flex items-center gap-4 p-4">
                <div className="text-3xl w-12 h-12 flex items-center justify-center bg-secondary/30 rounded-xl flex-shrink-0">
                  {item.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-display font-bold text-primary text-base">{item.name}</h3>
                    {item.popular && <span className="bg-accent/15 text-accent text-xs font-semibold px-2 py-0.5 rounded-full">Favorit</span>}
                    {!item.available && <span className="bg-muted text-muted-foreground text-xs font-semibold px-2 py-0.5 rounded-full">Nonaktif</span>}
                    <span className="bg-secondary text-foreground/60 text-xs px-2 py-0.5 rounded-full capitalize font-body">{item.category}</span>
                  </div>
                  <p className="text-xs text-foreground/60 font-body mt-0.5 truncate">{item.description}</p>
                </div>
                <div className="text-right flex-shrink-0 hidden sm:block">
                  <p className="font-display font-bold text-primary text-base">Rp {item.price.toLocaleString("id-ID")}</p>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button
                    onClick={() => handleTogglePopular(item.id)}
                    title={item.popular ? "Hapus dari favorit" : "Tandai favorit"}
                    className={`p-2 rounded-lg transition-colors ${item.popular ? "text-accent hover:bg-accent/10" : "text-foreground/30 hover:text-accent hover:bg-accent/10"}`}
                  >
                    <Star className="w-4 h-4" fill={item.popular ? "currentColor" : "none"} />
                  </button>
                  <button
                    onClick={() => handleToggleAvailable(item.id)}
                    title={item.available ? "Nonaktifkan" : "Aktifkan"}
                    className="p-2 rounded-lg hover:bg-secondary transition-colors"
                  >
                    {item.available
                      ? <ToggleRight className="w-5 h-5 text-green-600" />
                      : <ToggleLeft className="w-5 h-5 text-foreground/40" />}
                  </button>
                  <button onClick={() => handleOpenEdit(item)} className="p-2 rounded-lg hover:bg-secondary transition-colors text-foreground/60 hover:text-primary">
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button onClick={() => setDeleteConfirm(item.id)} className="p-2 rounded-lg hover:bg-destructive/10 transition-colors text-foreground/40 hover:text-destructive">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              {/* Mobile price */}
              <div className="sm:hidden px-4 pb-3 -mt-1">
                <p className="font-display font-bold text-primary text-sm">Rp {item.price.toLocaleString("id-ID")}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add/Edit Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-card w-full max-w-lg rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h2 className="font-display text-xl font-bold text-primary">{editingId ? "Edit Menu" : "Tambah Menu Baru"}</h2>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-secondary rounded-lg transition-colors">
                <X className="w-5 h-5 text-foreground" />
              </button>
            </div>
            <div className="p-6 space-y-5">
              {/* Icon picker */}
              <div>
                <label className="block text-sm font-semibold text-foreground/80 mb-2 font-body">Icon</label>
                <div className="flex flex-wrap gap-2">
                  {ICONS.map(ic => (
                    <button key={ic} onClick={() => setForm(f => ({ ...f, icon: ic }))}
                      className={`text-2xl w-10 h-10 rounded-lg transition-all ${form.icon === ic ? "bg-primary/20 ring-2 ring-primary" : "hover:bg-secondary"}`}>
                      {ic}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-foreground/80 mb-2 font-body">Nama Menu *</label>
                <input
                  type="text" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  placeholder="Contoh: Cappuccino"
                  className="w-full border border-border rounded-lg px-4 py-3 bg-background text-foreground font-body focus:outline-none focus:ring-2 focus:ring-primary/40 transition"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-foreground/80 mb-2 font-body">Deskripsi *</label>
                <textarea
                  value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  placeholder="Deskripsi singkat menu..."
                  rows={3}
                  className="w-full border border-border rounded-lg px-4 py-3 bg-background text-foreground font-body focus:outline-none focus:ring-2 focus:ring-primary/40 transition resize-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-foreground/80 mb-2 font-body">Harga (Rp) *</label>
                  <input
                    type="number" min="0" value={form.price || ""} onChange={e => setForm(f => ({ ...f, price: parseInt(e.target.value) || 0 }))}
                    placeholder="25000"
                    className="w-full border border-border rounded-lg px-4 py-3 bg-background text-foreground font-body focus:outline-none focus:ring-2 focus:ring-primary/40 transition"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground/80 mb-2 font-body">Kategori</label>
                  <select
                    value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as MenuItem["category"] }))}
                    className="w-full border border-border rounded-lg px-4 py-3 bg-background text-foreground font-body focus:outline-none focus:ring-2 focus:ring-primary/40 transition"
                  >
                    {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                  </select>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" checked={form.available} onChange={e => setForm(f => ({ ...f, available: e.target.checked }))} className="w-4 h-4 accent-primary" />
                  <span className="text-sm font-semibold font-body text-foreground/80">Tersedia</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" checked={form.popular} onChange={e => setForm(f => ({ ...f, popular: e.target.checked }))} className="w-4 h-4 accent-accent" />
                  <span className="text-sm font-semibold font-body text-foreground/80">Tandai Favorit ⭐</span>
                </label>
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowForm(false)} className="flex-1 border border-border py-3 rounded-lg font-semibold text-foreground/70 hover:bg-secondary transition-colors font-body">
                  Batal
                </button>
                <button
                  onClick={handleSave}
                  disabled={!form.name.trim() || !form.description.trim() || form.price <= 0}
                  className="flex-1 flex items-center justify-center gap-2 bg-primary text-primary-foreground py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed font-body"
                >
                  <Save className="w-4 h-4" />
                  {editingId ? "Simpan Perubahan" : "Tambah Menu"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-card w-full max-w-sm rounded-2xl shadow-2xl p-6">
            <div className="text-center mb-6">
              <div className="text-5xl mb-4">🗑️</div>
              <h3 className="font-display text-xl font-bold text-primary mb-2">Hapus Menu?</h3>
              <p className="text-foreground/70 font-body text-sm">
                <strong>"{items.find(i => i.id === deleteConfirm)?.name}"</strong> akan dihapus permanen.
              </p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 border border-border py-3 rounded-lg font-semibold text-foreground/70 hover:bg-secondary transition-colors font-body">
                Batal
              </button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 bg-destructive text-destructive-foreground py-3 rounded-lg font-semibold hover:bg-destructive/90 transition-colors font-body">
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
