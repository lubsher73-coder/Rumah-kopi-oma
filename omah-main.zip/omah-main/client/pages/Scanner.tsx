import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Coffee, QrCode, ChevronDown } from "lucide-react";

const AVAILABLE_TABLES = [1, 2, 3, 4, 5, 6];

export default function Scanner() {
  const navigate = useNavigate();
  const [orderType, setOrderType] = useState<"dine-in" | "pickup" | null>(null);
  const [tableNumber, setTableNumber] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [showTableDropdown, setShowTableDropdown] = useState(false);

  const handleStartOrder = () => {
    if (!orderType) {
      alert("Pilih tipe pesanan terlebih dahulu");
      return;
    }

    if (orderType === "dine-in" && !tableNumber) {
      alert("Masukkan nomor meja");
      return;
    }

    if (!customerName) {
      alert("Masukkan nama Anda");
      return;
    }

    // Store order session info
    const sessionId = Math.random().toString(36).substr(2, 9);
    sessionStorage.setItem(
      "orderSession",
      JSON.stringify({
        sessionId,
        type: orderType,
        table: orderType === "dine-in" ? tableNumber : null,
        name: customerName,
        createdAt: new Date().toISOString(),
      })
    );

    navigate("/menu-order");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card shadow-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Coffee className="w-8 h-8 text-primary" />
            <span className="font-display text-2xl font-bold text-primary">
              Rumah Kopi Oma
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link
              to="/"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Home
            </Link>
            <Link
              to="/scanner"
              className="text-primary font-bold transition-colors"
            >
              Order
            </Link>
            <Link
              to="/staff"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Kitchen
            </Link>
          </div>
          <button className="md:hidden">
            <svg
              className="w-6 h-6 text-foreground"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <QrCode className="w-16 h-16 text-accent mx-auto mb-4" />
            <h1 className="font-display text-4xl md:text-5xl font-bold text-primary mb-4">
              Mulai Pesan
            </h1>
            <p className="text-lg text-foreground/80 font-body">
              Scan kode QR di meja atau pilih opsi di bawah untuk memulai pemesanan
            </p>
          </div>

          {/* Order Type Selection */}
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border/50 mb-8">
            <h2 className="font-display text-2xl font-bold text-primary mb-6">
              Tipe Pesanan
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <button
                onClick={() => setOrderType("dine-in")}
                className={`p-6 rounded-lg border-2 transition-all font-body font-semibold text-lg ${
                  orderType === "dine-in"
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-secondary/30 text-foreground"
                }`}
              >
                🪑 Makan di Tempat
              </button>
              <button
                onClick={() => setOrderType("pickup")}
                className={`p-6 rounded-lg border-2 transition-all font-body font-semibold text-lg ${
                  orderType === "pickup"
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-secondary/30 text-foreground"
                }`}
              >
                📦 Bawa Pulang
              </button>
            </div>

            {/* Table Selection - Only show for dine-in */}
            {orderType === "dine-in" && (
              <div className="mb-6">
                <label className="block text-sm font-semibold text-foreground mb-4">
                  Pilih Nomor Meja
                </label>

                {/* Table Grid */}
                <div className="grid grid-cols-3 md:grid-cols-6 gap-3 mb-4">
                  {AVAILABLE_TABLES.map((table) => (
                    <button
                      key={table}
                      onClick={() => setTableNumber(table.toString())}
                      className={`p-4 rounded-lg border-2 font-display text-2xl font-bold transition-all ${
                        tableNumber === table.toString()
                          ? "border-primary bg-primary/20 text-primary"
                          : "border-border bg-secondary/50 text-foreground hover:border-primary hover:bg-primary/10"
                      }`}
                    >
                      {table}
                    </button>
                  ))}
                </div>

                {/* Dropdown Option */}
                <div className="relative">
                  <button
                    onClick={() => setShowTableDropdown(!showTableDropdown)}
                    className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-body bg-card flex items-center justify-between"
                  >
                    <span>
                      {tableNumber ? `Meja ${tableNumber} dipilih` : "Atau pilih dari dropdown"}
                    </span>
                    <ChevronDown
                      className={`w-5 h-5 transition-transform ${
                        showTableDropdown ? "rotate-180" : ""
                      }`}
                    />
                  </button>

                  {showTableDropdown && (
                    <div className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-lg shadow-lg z-10">
                      {AVAILABLE_TABLES.map((table) => (
                        <button
                          key={table}
                          onClick={() => {
                            setTableNumber(table.toString());
                            setShowTableDropdown(false);
                          }}
                          className={`w-full px-4 py-3 text-left font-body transition-colors ${
                            tableNumber === table.toString()
                              ? "bg-primary/20 text-primary font-semibold"
                              : "hover:bg-secondary/50 text-foreground"
                          }`}
                        >
                          Meja {table}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Customer Name Input */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-foreground mb-2">
                Nama Anda
              </label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="Contoh: Budi"
                className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-body"
              />
            </div>

            {/* Start Button */}
            <button
              onClick={handleStartOrder}
              className="w-full bg-primary text-primary-foreground py-4 rounded-lg font-semibold text-lg hover:bg-primary/90 transition-colors font-body"
            >
              Lanjut ke Menu →
            </button>
          </div>

          {/* QR Code Info */}
          <div className="bg-secondary/30 rounded-xl p-6 text-center border border-border/50">
            <p className="text-sm text-foreground/70 font-body">
              💡 Tip: Setiap meja memiliki kode QR unik. Scan dengan kamera ponsel Anda untuk langsung mulai pesan!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
