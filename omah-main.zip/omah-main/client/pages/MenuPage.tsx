import { useState, useEffect, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Coffee, ShoppingCart, X, Plus, Minus } from "lucide-react";
import { getMenuItems, type MenuItem } from "../lib/menuData";

interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  notes?: string;
}


// Lazy loaded menu item component
const MenuItemCard = ({
  item,
  onAddToCart,
}: {
  item: MenuItem;
  onAddToCart: (item: MenuItem) => void;
}) => {
  return (
    <div className="bg-card rounded-lg sm:rounded-xl p-4 sm:p-6 shadow-md hover:shadow-lg transition-shadow border border-border/50 h-full flex flex-col">
      <div className="flex justify-between items-start mb-3 flex-1">
        <span className="text-3xl sm:text-4xl">{item.icon}</span>
        <button
          onClick={() => onAddToCart(item)}
          className="bg-primary text-primary-foreground p-2 rounded-lg hover:bg-primary/90 transition-colors flex-shrink-0"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>
      <h3 className="font-display text-lg sm:text-xl font-bold text-primary mb-1 line-clamp-2">
        {item.name}
      </h3>
      <p className="text-xs sm:text-sm text-foreground/70 font-body mb-4 flex-1 line-clamp-2">
        {item.description}
      </p>
      <p className="font-bold text-base sm:text-lg text-primary">
        Rp {item.price.toLocaleString("id-ID")}
      </p>
    </div>
  );
};

export default function MenuPage() {
  const navigate = useNavigate();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<
    "kopi" | "minuman" | "makanan" | "all"
  >("all");
  const [showCart, setShowCart] = useState(false);
  const [sessionInfo, setSessionInfo] = useState<any>(null);
  const [loadedItems, setLoadedItems] = useState<Set<string>>(new Set());
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);

  useEffect(() => {
    const session = sessionStorage.getItem("orderSession");
    if (!session) {
      navigate("/scanner");
      return;
    }
    setSessionInfo(JSON.parse(session));

    const savedCart = sessionStorage.getItem("cart");
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }

    const allItems = getMenuItems().filter(i => i.available);
    setMenuItems(allItems);

    const timer = setTimeout(() => {
      setLoadedItems(new Set(allItems.map((item) => item.id)));
    }, 300);

    return () => clearTimeout(timer);
  }, [navigate]);

  const filteredItems =
    selectedCategory === "all"
      ? menuItems
      : menuItems.filter((item) => item.category === selectedCategory);

  const handleAddToCart = useCallback((item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.find((ci) => ci.menuItem.id === item.id);
      if (existing) {
        return prev.map((ci) =>
          ci.menuItem.id === item.id
            ? { ...ci, quantity: ci.quantity + 1 }
            : ci
        );
      }
      return [...prev, { menuItem: item, quantity: 1 }];
    });
  }, []);

  const handleRemoveFromCart = (itemId: string) => {
    setCart((prev) =>
      prev.filter((ci) => ci.menuItem.id !== itemId)
    );
  };

  const handleUpdateQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(itemId);
      return;
    }
    setCart((prev) =>
      prev.map((ci) =>
        ci.menuItem.id === itemId ? { ...ci, quantity } : ci
      )
    );
  };

  const totalPrice = cart.reduce(
    (sum, item) => sum + item.menuItem.price * item.quantity,
    0
  );

  const handleCheckout = () => {
    if (cart.length === 0) {
      alert("Silakan pilih minimal satu item");
      return;
    }
    sessionStorage.setItem("cart", JSON.stringify(cart));
    navigate("/checkout");
  };

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card shadow-md">
        <div className="container mx-auto px-3 sm:px-4 py-3 sm:py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
            <Coffee className="w-6 sm:w-8 h-6 sm:h-8 text-primary" />
            <span className="font-display text-lg sm:text-2xl font-bold text-primary hidden sm:inline">
              Rumah Kopi Oma
            </span>
            <span className="font-display text-lg sm:text-2xl font-bold text-primary sm:hidden">
              Menu
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link
              to="/"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Home
            </Link>
            <Link
              to="/scanner"
              className="text-primary font-bold transition-colors"
            >
              Order
            </Link>
            <Link
              to="/staff"
              className="text-foreground hover:text-primary transition-colors font-medium"
            >
              Kitchen
            </Link>
          </div>
          <button
            onClick={() => setShowCart(true)}
            className="relative p-2 hover:bg-secondary rounded-lg transition-colors flex-shrink-0"
          >
            <ShoppingCart className="w-5 sm:w-6 h-5 sm:h-6 text-primary" />
            {cart.length > 0 && (
              <span className="absolute top-0 right-0 bg-accent text-primary-foreground rounded-full w-5 h-5 text-xs flex items-center justify-center font-bold">
                {cart.length}
              </span>
            )}
          </button>
        </div>
      </nav>

      <div className="container mx-auto px-3 sm:px-4 py-6 sm:py-12">
        {/* Header */}
        <div className="mb-8 sm:mb-12">
          <h1 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-primary mb-2">
            Menu
          </h1>
          {sessionInfo && (
            <p className="text-base sm:text-lg text-foreground/80 font-body">
              {sessionInfo.type === "dine-in"
                ? `Meja ${sessionInfo.table} • `
                : "Bawa Pulang • "}
              <span className="font-semibold">{sessionInfo.name}</span>
            </p>
          )}
        </div>

        {/* Category Filter - Responsive */}
        <div className="flex gap-2 sm:gap-3 mb-8 sm:mb-12 overflow-x-auto pb-2 -mx-3 sm:mx-0 px-3 sm:px-0">
          <button
            onClick={() => setSelectedCategory("all")}
            className={`px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-semibold whitespace-nowrap transition-all text-sm sm:text-base ${
              selectedCategory === "all"
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-foreground hover:bg-secondary/80"
            }`}
          >
            Semua
          </button>
          <button
            onClick={() => setSelectedCategory("kopi")}
            className={`px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-semibold whitespace-nowrap transition-all text-sm sm:text-base ${
              selectedCategory === "kopi"
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-foreground hover:bg-secondary/80"
            }`}
          >
            ☕ Kopi
          </button>
          <button
            onClick={() => setSelectedCategory("minuman")}
            className={`px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-semibold whitespace-nowrap transition-all text-sm sm:text-base ${
              selectedCategory === "minuman"
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-foreground hover:bg-secondary/80"
            }`}
          >
            🧋 Minuman
          </button>
          <button
            onClick={() => setSelectedCategory("makanan")}
            className={`px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-semibold whitespace-nowrap transition-all text-sm sm:text-base ${
              selectedCategory === "makanan"
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-foreground hover:bg-secondary/80"
            }`}
          >
            🥐 Makanan
          </button>
        </div>

        {/* Menu Items Grid - Responsive */}
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6 mb-12">
          {filteredItems.map((item) => (
            <div key={item.id} className={loadedItems.has(item.id) ? "" : "opacity-50"}>
              <MenuItemCard
                item={item}
                onAddToCart={handleAddToCart}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Cart Sidebar - Responsive */}
      {showCart && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center md:justify-end">
          <div className="bg-card w-full md:w-96 rounded-t-2xl md:rounded-xl max-h-[90vh] md:max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Cart Header */}
            <div className="flex items-center justify-between p-4 sm:p-6 border-b border-border flex-shrink-0">
              <h2 className="font-display text-xl sm:text-2xl font-bold text-primary">
                Keranjang
              </h2>
              <button
                onClick={() => setShowCart(false)}
                className="p-2 hover:bg-secondary rounded-lg transition-colors"
              >
                <X className="w-5 sm:w-6 h-5 sm:h-6 text-foreground" />
              </button>
            </div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
              {cart.length === 0 ? (
                <p className="text-center text-foreground/60 py-8 font-body">
                  Keranjang kosong
                </p>
              ) : (
                <div className="space-y-3 sm:space-y-4">
                  {cart.map((item) => (
                    <div
                      key={item.menuItem.id}
                      className="bg-secondary/30 rounded-lg p-3 sm:p-4 border border-border/50"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-primary font-display text-sm sm:text-base truncate">
                            {item.menuItem.name}
                          </h4>
                          <p className="text-xs sm:text-sm text-foreground/70 font-body">
                            Rp {item.menuItem.price.toLocaleString("id-ID")}
                          </p>
                        </div>
                        <button
                          onClick={() => handleRemoveFromCart(item.menuItem.id)}
                          className="text-foreground/60 hover:text-accent transition-colors flex-shrink-0 ml-2"
                        >
                          <X className="w-4 sm:w-5 h-4 sm:h-5" />
                        </button>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() =>
                            handleUpdateQuantity(
                              item.menuItem.id,
                              item.quantity - 1
                            )
                          }
                          className="p-1 hover:bg-border rounded transition-colors"
                        >
                          <Minus className="w-4 h-4 text-foreground" />
                        </button>
                        <span className="flex-1 text-center font-semibold font-body text-sm sm:text-base">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            handleUpdateQuantity(
                              item.menuItem.id,
                              item.quantity + 1
                            )
                          }
                          className="p-1 hover:bg-border rounded transition-colors"
                        >
                          <Plus className="w-4 h-4 text-foreground" />
                        </button>
                      </div>
                      <p className="text-right text-xs sm:text-sm font-bold text-primary mt-2 font-body">
                        Rp{" "}
                        {(
                          item.menuItem.price * item.quantity
                        ).toLocaleString("id-ID")}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Cart Footer */}
            {cart.length > 0 && (
              <div className="border-t border-border p-4 sm:p-6 space-y-4 flex-shrink-0">
                <div className="flex justify-between items-center text-base sm:text-lg font-bold">
                  <span className="text-foreground font-body">Total:</span>
                  <span className="text-primary font-display">
                    Rp {totalPrice.toLocaleString("id-ID")}
                  </span>
                </div>
                <button
                  onClick={handleCheckout}
                  className="w-full bg-primary text-primary-foreground py-3 sm:py-4 rounded-lg font-semibold hover:bg-primary/90 transition-colors font-body text-sm sm:text-base"
                >
                  Lanjut ke Checkout
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
