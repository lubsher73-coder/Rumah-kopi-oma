import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Coffee, AlertCircle, CheckCircle, Clock, Trash2 } from "lucide-react";

interface Order {
  orderId: string;
  sessionId: string;
  type: "dine-in" | "pickup";
  table: number | null;
  customerName: string;
  items: Array<{
    menuItem: {
      id: string;
      name: string;
      price: number;
    };
    quantity: number;
  }>;
  specialNotes?: string;
  totalPrice: number;
  status: "pending" | "preparing" | "ready" | "completed";
  createdAt: string;
  estimatedTime: string;
}

export default function Staff() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [filter, setFilter] = useState<"all" | "pending" | "preparing" | "ready">(
    "all"
  );
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [showAuth, setShowAuth] = useState(true);

  // Simple password for staff area (in production, use proper authentication)
  const STAFF_PASSWORD = "oma123";

  useEffect(() => {
    // Load orders from localStorage
    const savedOrders = JSON.parse(localStorage.getItem("orders") || "[]");
    setOrders(savedOrders);

    // Listen for new orders
    const handleNewOrder = (event: any) => {
      const newOrder = event.detail;
      setOrders((prev) => [newOrder, ...prev]);
    };

    window.addEventListener("orderPlaced", handleNewOrder);

    // Auto-refresh orders every 2 seconds
    const interval = setInterval(() => {
      const savedOrders = JSON.parse(localStorage.getItem("orders") || "[]");
      setOrders(savedOrders);
    }, 2000);

    return () => {
      window.removeEventListener("orderPlaced", handleNewOrder);
      clearInterval(interval);
    };
  }, []);

  const handleLogin = () => {
    if (password === STAFF_PASSWORD) {
      setIsAuthenticated(true);
      setShowAuth(false);
      setPassword("");
    } else {
      alert("Password salah!");
      setPassword("");
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setShowAuth(true);
    navigate("/");
  };

  const handleStatusChange = (orderId: string, newStatus: Order["status"]) => {
    const updatedOrders = orders.map((order) =>
      order.orderId === orderId ? { ...order, status: newStatus } : order
    );
    setOrders(updatedOrders);
    localStorage.setItem("orders", JSON.stringify(updatedOrders));
  };

  const handleDeleteOrder = (orderId: string) => {
    const updatedOrders = orders.filter((order) => order.orderId !== orderId);
    setOrders(updatedOrders);
    localStorage.setItem("orders", JSON.stringify(updatedOrders));
  };

  const filteredOrders =
    filter === "all"
      ? orders
      : orders.filter((order) => order.status === filter);

  const pendingCount = orders.filter((o) => o.status === "pending").length;
  const preparingCount = orders.filter((o) => o.status === "preparing").length;
  const readyCount = orders.filter((o) => o.status === "ready").length;

  if (showAuth) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="max-w-md w-full mx-auto px-4">
          <div className="bg-card rounded-xl p-8 shadow-lg border border-border/50">
            <div className="text-center mb-8">
              <Coffee className="w-12 h-12 text-primary mx-auto mb-4" />
              <h1 className="font-display text-3xl font-bold text-primary">
                Sistem Dapur
              </h1>
              <p className="text-foreground/60 font-body mt-2">
                Rumah Kopi Oma Staff
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block font-semibold text-foreground mb-2 font-body">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleLogin()}
                  placeholder="Masukkan password"
                  className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-body"
                  autoFocus
                />
              </div>
              <button
                onClick={handleLogin}
                className="w-full bg-primary text-primary-foreground py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors font-body"
              >
                Masuk
              </button>
            </div>

            <p className="text-center text-sm text-foreground/60 mt-6 font-body">
              Demo: Gunakan password <strong>oma123</strong>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card shadow-lg border-b-2 border-primary">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Coffee className="w-8 h-8 text-primary" />
            <span className="font-display text-2xl font-bold text-primary">
              Sistem Dapur
            </span>
          </Link>
          <div className="flex items-center gap-3">
            <Link
              to="/admin/menu"
              className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-semibold hover:bg-primary/90 transition-colors font-body text-sm"
            >
              Kelola Menu
            </Link>
            <button
              onClick={handleLogout}
              className="bg-accent text-accent-foreground px-4 py-2 rounded-lg font-semibold hover:bg-accent/90 transition-colors font-body text-sm"
            >
              Keluar
            </button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-card rounded-xl p-6 shadow-lg border-2 border-red-300 border-border/50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-foreground/60 font-body text-sm">
                  Pesanan Baru
                </p>
                <p className="font-display text-5xl font-bold text-red-500">
                  {pendingCount}
                </p>
              </div>
              <AlertCircle className="w-12 h-12 text-red-500" />
            </div>
          </div>

          <div className="bg-card rounded-xl p-6 shadow-lg border-2 border-yellow-300 border-border/50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-foreground/60 font-body text-sm">
                  Sedang Disiapkan
                </p>
                <p className="font-display text-5xl font-bold text-yellow-500">
                  {preparingCount}
                </p>
              </div>
              <Clock className="w-12 h-12 text-yellow-500" />
            </div>
          </div>

          <div className="bg-card rounded-xl p-6 shadow-lg border-2 border-green-300 border-border/50">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-foreground/60 font-body text-sm">
                  Siap Diambil
                </p>
                <p className="font-display text-5xl font-bold text-green-500">
                  {readyCount}
                </p>
              </div>
              <CheckCircle className="w-12 h-12 text-green-500" />
            </div>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-3 mb-8 overflow-x-auto pb-2">
          <button
            onClick={() => setFilter("all")}
            className={`px-6 py-3 rounded-lg font-semibold whitespace-nowrap transition-all ${
              filter === "all"
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-foreground hover:bg-secondary/80"
            } font-body`}
          >
            Semua ({orders.length})
          </button>
          <button
            onClick={() => setFilter("pending")}
            className={`px-6 py-3 rounded-lg font-semibold whitespace-nowrap transition-all ${
              filter === "pending"
                ? "bg-red-500 text-white"
                : "bg-secondary text-foreground hover:bg-secondary/80"
            } font-body`}
          >
            Baru ({pendingCount})
          </button>
          <button
            onClick={() => setFilter("preparing")}
            className={`px-6 py-3 rounded-lg font-semibold whitespace-nowrap transition-all ${
              filter === "preparing"
                ? "bg-yellow-500 text-white"
                : "bg-secondary text-foreground hover:bg-secondary/80"
            } font-body`}
          >
            Diproses ({preparingCount})
          </button>
          <button
            onClick={() => setFilter("ready")}
            className={`px-6 py-3 rounded-lg font-semibold whitespace-nowrap transition-all ${
              filter === "ready"
                ? "bg-green-500 text-white"
                : "bg-secondary text-foreground hover:bg-secondary/80"
            } font-body`}
          >
            Siap ({readyCount})
          </button>
        </div>

        {/* Orders Grid */}
        {filteredOrders.length === 0 ? (
          <div className="text-center py-16">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <p className="text-xl text-foreground/60 font-body">
              {filter === "all"
                ? "Tidak ada pesanan"
                : `Tidak ada pesanan ${filter}`}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredOrders.map((order) => (
              <div
                key={order.orderId}
                className={`rounded-xl p-6 shadow-lg border-2 ${
                  order.status === "pending"
                    ? "bg-red-50 border-red-300"
                    : order.status === "preparing"
                    ? "bg-yellow-50 border-yellow-300"
                    : order.status === "ready"
                    ? "bg-green-50 border-green-300"
                    : "bg-gray-50 border-gray-300"
                }`}
              >
                {/* Header */}
                <div className="mb-4 pb-4 border-b-2 border-current/20">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="text-xs font-body text-foreground/60 uppercase tracking-wide">
                        Order #{order.orderId}
                      </p>
                      <p className="font-display text-3xl font-bold text-primary">
                        {order.customerName}
                      </p>
                    </div>
                    <span
                      className={`px-4 py-2 rounded-full font-bold text-sm font-body ${
                        order.status === "pending"
                          ? "bg-red-200 text-red-800"
                          : order.status === "preparing"
                          ? "bg-yellow-200 text-yellow-800"
                          : order.status === "ready"
                          ? "bg-green-200 text-green-800"
                          : "bg-gray-200 text-gray-800"
                      }`}
                    >
                      {order.status === "pending"
                        ? "BARU"
                        : order.status === "preparing"
                        ? "DIPROSES"
                        : order.status === "ready"
                        ? "SIAP"
                        : "SELESAI"}
                    </span>
                  </div>

                  <div className="flex gap-4 text-sm font-body">
                    {order.type === "dine-in" && (
                      <span className="bg-primary/20 text-primary px-3 py-1 rounded-full">
                        🪑 Meja {order.table}
                      </span>
                    )}
                    {order.type === "pickup" && (
                      <span className="bg-accent/20 text-accent px-3 py-1 rounded-full">
                        📦 Bawa Pulang
                      </span>
                    )}
                    <span className="text-foreground/60">
                      {new Date(order.createdAt).toLocaleTimeString("id-ID", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                </div>

                {/* Items */}
                <div className="mb-4 pb-4 border-b-2 border-current/20">
                  <h4 className="font-semibold text-primary font-body mb-2">
                    Item Pesanan:
                  </h4>
                  <ul className="space-y-2">
                    {order.items.map((item, i) => (
                      <li
                        key={i}
                        className="flex justify-between items-center text-sm font-body"
                      >
                        <span>
                          <strong>{item.quantity}x</strong> {item.menuItem.name}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Special Notes */}
                {order.specialNotes && (
                  <div className="mb-4 pb-4 border-b-2 border-current/20 bg-white/50 rounded p-3">
                    <p className="font-body text-sm text-foreground/80">
                      <strong className="text-accent">Catatan:</strong>{" "}
                      {order.specialNotes}
                    </p>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-3">
                  {order.status === "pending" && (
                    <button
                      onClick={() =>
                        handleStatusChange(order.orderId, "preparing")
                      }
                      className="flex-1 bg-yellow-500 text-white py-2 rounded-lg font-semibold hover:bg-yellow-600 transition-colors font-body"
                    >
                      Mulai Siapkan
                    </button>
                  )}
                  {order.status === "preparing" && (
                    <button
                      onClick={() => handleStatusChange(order.orderId, "ready")}
                      className="flex-1 bg-green-500 text-white py-2 rounded-lg font-semibold hover:bg-green-600 transition-colors font-body"
                    >
                      Siap!
                    </button>
                  )}
                  {order.status === "ready" && (
                    <button
                      onClick={() =>
                        handleStatusChange(order.orderId, "completed")
                      }
                      className="flex-1 bg-blue-500 text-white py-2 rounded-lg font-semibold hover:bg-blue-600 transition-colors font-body"
                    >
                      Diambil
                    </button>
                  )}
                  <button
                    onClick={() => handleDeleteOrder(order.orderId)}
                    className="bg-red-200 text-red-700 p-2 rounded-lg hover:bg-red-300 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
