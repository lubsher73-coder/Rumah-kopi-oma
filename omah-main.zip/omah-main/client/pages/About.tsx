import { useState } from "react";
import { Link } from "react-router-dom";
import { Coffee, Heart, Award, Users, Star } from "lucide-react";

export default function About() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <nav className="sticky top-0 z-50 bg-card shadow-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Coffee className="w-8 h-8 text-primary" />
            <span className="font-display text-2xl font-bold text-primary">Rumah Kopi Oma</span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link to="/" className="text-foreground hover:text-primary transition-colors font-medium">Home</Link>
            <Link to="/menu" className="text-foreground hover:text-primary transition-colors font-medium">Menu</Link>
            <Link to="/about" className="text-primary font-bold">About</Link>
            <Link to="/contact" className="text-foreground hover:text-primary transition-colors font-medium">Contact</Link>
            <Link to="/scanner" className="bg-accent text-accent-foreground px-4 py-2 rounded-lg font-semibold hover:bg-accent/90 transition-colors">Pesan Sekarang</Link>
          </div>
          <button className="md:hidden p-2" onClick={() => setMobileOpen(!mobileOpen)}>
            <svg className="w-6 h-6 text-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={mobileOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
            </svg>
          </button>
        </div>
        {mobileOpen && (
          <div className="md:hidden bg-card border-t border-border px-4 py-4 space-y-3">
            <Link to="/" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileOpen(false)}>Home</Link>
            <Link to="/menu" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileOpen(false)}>Menu</Link>
            <Link to="/about" className="block text-primary font-bold py-2" onClick={() => setMobileOpen(false)}>About</Link>
            <Link to="/contact" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileOpen(false)}>Contact</Link>
            <Link to="/scanner" className="block bg-accent text-accent-foreground px-4 py-3 rounded-lg font-semibold text-center" onClick={() => setMobileOpen(false)}>Pesan Sekarang</Link>
          </div>
        )}
      </nav>

      {/* Hero */}
      <section className="bg-gradient-to-br from-secondary via-background to-background py-20 px-4">
        <div className="container mx-auto text-center max-w-3xl">
          <div className="text-6xl mb-6">☕</div>
          <h1 className="font-display text-4xl md:text-6xl font-bold text-primary mb-6">Cerita Kami</h1>
          <p className="text-lg md:text-xl text-foreground/80 font-body leading-relaxed">
            Dari dapur kecil sang Oma hingga menjadi tempat favorit komunitas — inilah perjalanan cinta kami terhadap kopi.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <h2 className="font-display text-3xl md:text-4xl font-bold text-primary mb-6">Bermula dari Satu Cangkir</h2>
              <p className="text-foreground/80 font-body text-lg leading-relaxed mb-4">
                Rumah Kopi Oma lahir dari kenangan manis: setiap pagi, aroma kopi Oma yang mengepul dari dapur kecil membangunkan seluruh keluarga dengan hangat.
              </p>
              <p className="text-foreground/70 font-body leading-relaxed">
                Terinspirasi dari semangat dan resep turun-temurun itu, kami mendirikan Rumah Kopi Oma pada 2019 — tempat di mana setiap tamu diperlakukan seperti anggota keluarga.
              </p>
            </div>
            <div className="bg-gradient-to-br from-accent/20 to-secondary rounded-2xl h-72 flex items-center justify-center shadow-inner">
              <Coffee className="w-28 h-28 text-primary opacity-40" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-20">
            <div className="order-2 md:order-1 bg-gradient-to-br from-secondary to-accent/10 rounded-2xl h-72 flex items-center justify-center shadow-inner">
              <Heart className="w-28 h-28 text-accent opacity-40" />
            </div>
            <div className="order-1 md:order-2">
              <h2 className="font-display text-3xl md:text-4xl font-bold text-primary mb-6">Dibuat dengan Cinta</h2>
              <p className="text-foreground/80 font-body text-lg leading-relaxed mb-4">
                Setiap biji kopi kami dipilih langsung dari petani lokal terbaik di Aceh, Toraja, dan Flores. Kami percaya kualitas dimulai dari sumbernya.
              </p>
              <p className="text-foreground/70 font-body leading-relaxed">
                Barista kami terlatih untuk menyeduh setiap cangkir dengan presisi dan penuh rasa hormat terhadap biji kopi pilihan.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 px-4 bg-secondary/30">
        <div className="container mx-auto max-w-5xl">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-primary text-center mb-14">Nilai-Nilai Kami</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            {[
              { icon: <Award className="w-10 h-10 text-accent" />, title: "Kualitas Terbaik", desc: "Biji kopi single-origin pilihan, diseduh dengan teknik terbaik oleh barista berpengalaman." },
              { icon: <Heart className="w-10 h-10 text-accent" />, title: "Kehangatan Keluarga", desc: "Setiap tamu adalah anggota keluarga. Kami menyambut dengan senyum dan pelayanan tulus." },
              { icon: <Users className="w-10 h-10 text-accent" />, title: "Komunitas Lokal", desc: "Kami bangga mendukung petani kopi lokal dan memberikan ruang bagi komunitas berkumpul." },
            ].map((v, i) => (
              <div key={i} className="bg-card rounded-xl p-8 shadow-md border border-border/50 text-center hover:shadow-lg transition-shadow">
                <div className="flex justify-center mb-4">{v.icon}</div>
                <h3 className="font-display text-xl font-bold text-primary mb-3">{v.title}</h3>
                <p className="text-foreground/70 font-body text-sm leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 px-4 bg-primary">
        <div className="container mx-auto max-w-4xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { num: "2019", label: "Tahun Berdiri" },
              { num: "5.000+", label: "Pelanggan Setia" },
              { num: "20+", label: "Varian Menu" },
              { num: "4.9 ★", label: "Rating Rata-rata" },
            ].map((s, i) => (
              <div key={i}>
                <p className="font-display text-3xl md:text-4xl font-bold text-primary-foreground mb-2">{s.num}</p>
                <p className="text-primary-foreground/70 font-body text-sm">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-primary mb-4">Tim Kami</h2>
          <p className="text-foreground/70 font-body mb-14 text-lg">Orang-orang berdedikasi di balik setiap cangkir</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            {[
              { name: "Sari Dewi", role: "Head Barista", emoji: "👩‍🍳", desc: "10 tahun pengalaman, juara barista regional 2022" },
              { name: "Budi Santoso", role: "Founder & Manager", emoji: "👨‍💼", desc: "Cucu Oma yang meneruskan warisan kopi keluarga" },
              { name: "Rina Wati", role: "Kitchen Chef", emoji: "👩‍🍳", desc: "Ahli pastry & makanan pendamping kopi terbaik" },
            ].map((t, i) => (
              <div key={i} className="bg-card rounded-xl p-8 shadow-md border border-border/50 hover:shadow-lg transition-shadow">
                <div className="text-5xl mb-4">{t.emoji}</div>
                <h3 className="font-display text-lg font-bold text-primary mb-1">{t.name}</h3>
                <p className="text-accent font-semibold text-sm mb-3 font-body">{t.role}</p>
                <p className="text-foreground/60 text-sm font-body">{t.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 bg-gradient-to-r from-primary to-primary/80">
        <div className="container mx-auto text-center">
          <Star className="w-10 h-10 text-accent mx-auto mb-4" />
          <h2 className="font-display text-3xl font-bold text-primary-foreground mb-4">Bergabunglah dengan Keluarga Oma</h2>
          <p className="text-primary-foreground/80 font-body mb-8">Kunjungi kami hari ini dan rasakan kehangatan yang telah kami jaga selama bertahun-tahun</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/scanner" className="inline-block bg-accent text-accent-foreground px-8 py-4 rounded-xl font-semibold text-lg hover:bg-accent/90 transition-colors shadow-lg">Pesan Sekarang</Link>
            <Link to="/contact" className="inline-block bg-primary-foreground text-primary px-8 py-4 rounded-xl font-semibold text-lg hover:bg-primary-foreground/90 transition-colors shadow-lg">Hubungi Kami</Link>
          </div>
        </div>
      </section>

      <footer className="bg-card border-t border-border py-10 px-4">
        <div className="container mx-auto text-center text-foreground/60">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Coffee className="w-5 h-5 text-primary" />
            <span className="font-display text-lg font-bold text-primary">Rumah Kopi Oma</span>
          </div>
          <p className="font-body text-sm">© 2024 Rumah Kopi Oma. Semua hak dilindungi.</p>
        </div>
      </footer>
    </div>
  );
}
