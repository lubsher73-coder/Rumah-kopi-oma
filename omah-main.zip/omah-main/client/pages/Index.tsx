import { useState } from "react";
import { Link } from "react-router-dom";
import { Coffee, MapPin, Clock, Phone } from "lucide-react";

export default function Index() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-card shadow-md">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Coffee className="w-8 h-8 text-primary" />
            <span className="font-display text-2xl font-bold text-primary">
              Rumah Kopi Oma
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link to="/" className="text-primary font-bold transition-colors">Home</Link>
            <Link to="/menu" className="text-foreground hover:text-primary transition-colors font-medium">Menu</Link>
            <Link to="/about" className="text-foreground hover:text-primary transition-colors font-medium">About</Link>
            <Link to="/contact" className="text-foreground hover:text-primary transition-colors font-medium">Contact</Link>
            <Link to="/scanner" className="bg-accent text-accent-foreground px-4 py-2 rounded-lg font-semibold hover:bg-accent/90 transition-colors">
              Pesan Sekarang
            </Link>
          </div>
          <button className="md:hidden p-2" onClick={() => setMobileOpen(!mobileOpen)}>
            <svg className="w-6 h-6 text-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={mobileOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
            </svg>
          </button>
        </div>
        {mobileOpen && (
          <div className="md:hidden bg-card border-t border-border px-4 py-4 space-y-3">
            <Link to="/" className="block text-primary font-bold py-2" onClick={() => setMobileOpen(false)}>Home</Link>
            <Link to="/menu" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileOpen(false)}>Menu</Link>
            <Link to="/about" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileOpen(false)}>About</Link>
            <Link to="/contact" className="block text-foreground hover:text-primary font-medium py-2" onClick={() => setMobileOpen(false)}>Contact</Link>
            <Link to="/scanner" className="block bg-accent text-accent-foreground px-4 py-3 rounded-lg font-semibold text-center" onClick={() => setMobileOpen(false)}>Pesan Sekarang</Link>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 md:py-32 px-4 bg-gradient-to-b from-secondary to-background">
        <div className="container mx-auto text-center">
          <h1 className="font-display text-5xl md:text-7xl font-bold text-primary mb-4">
            Selamat Datang
          </h1>
          <p className="text-xl md:text-2xl text-foreground mb-8 font-body">
            Rumah Kopi Oma
          </p>
          <p className="text-lg md:text-xl text-foreground/80 mb-12 max-w-2xl mx-auto font-body">
            Nikmati kopi berkualitas tinggi di suasana cozy yang penuh kehangatan.
            Tempat sempurna untuk bersantai, bekerja, atau bertemu teman.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/scanner"
              className="inline-block bg-accent text-accent-foreground px-8 py-4 rounded-lg font-semibold text-lg hover:bg-accent/90 transition-colors shadow-lg"
            >
              Mulai Pesan Sekarang
            </Link>
            <Link
              to="/menu"
              className="inline-block bg-primary text-primary-foreground px-8 py-4 rounded-lg font-semibold text-lg hover:bg-primary/90 transition-colors shadow-lg"
            >
              Lihat Menu
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-center text-primary mb-16">
            Favorit Kami
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Espresso Premium",
                desc: "Kopi pilihan dengan cita rasa kaya dan aromaatis",
                icon: "☕",
              },
              {
                name: "Cappuccino Latte Art",
                desc: "Kombinasi sempurna susu dan espresso dengan seni latte",
                icon: "🎨",
              },
              {
                name: "Cold Brew Spesial",
                desc: "Kopi dingin yang menyegarkan, sempurna di hari panas",
                icon: "🧊",
              },
            ].map((product, i) => (
              <div
                key={i}
                className="bg-card rounded-xl p-8 shadow-md hover:shadow-xl transition-shadow border border-border/50"
              >
                <div className="text-5xl mb-4">{product.icon}</div>
                <h3 className="font-display text-2xl font-bold text-primary mb-3">
                  {product.name}
                </h3>
                <p className="text-foreground/80 font-body">{product.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Preview */}
      <section className="py-20 px-4 bg-secondary/30">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-display text-4xl font-bold text-primary mb-6">
                Tentang Oma
              </h2>
              <p className="text-lg text-foreground/80 mb-6 font-body">
                Rumah Kopi Oma dimulai dari passion sederhana: menciptakan tempat di mana 
                setiap orang bisa merasa diterima dan nyaman. Dengan suasana yang hangat dan 
                kopi yang berkualitas, kami menghadirkan pengalaman kafe yang autentik.
              </p>
              <Link
                to="/about"
                className="inline-block text-primary font-semibold hover:text-primary/80 transition-colors flex items-center gap-2"
              >
                Baca Cerita Lengkap →
              </Link>
            </div>
            <div className="bg-gradient-to-br from-accent/20 to-secondary rounded-xl h-64 flex items-center justify-center">
              <Coffee className="w-24 h-24 text-accent opacity-50" />
            </div>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <h2 className="font-display text-4xl font-bold text-center text-primary mb-16">
            Kunjungi Kami
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <MapPin className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="font-display text-xl font-bold text-primary mb-2">
                Lokasi
              </h3>
              <p className="text-foreground/80 font-body">
                Jl. Subyek Merdeka No. 42<br />
                Suburban Area
              </p>
            </div>
            <div className="text-center">
              <Clock className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="font-display text-xl font-bold text-primary mb-2">
                Jam Operasional
              </h3>
              <p className="text-foreground/80 font-body">
                Senin - Jumat: 7:00 - 21:00<br />
                Sabtu - Minggu: 8:00 - 22:00
              </p>
            </div>
            <div className="text-center">
              <Phone className="w-12 h-12 text-accent mx-auto mb-4" />
              <h3 className="font-display text-xl font-bold text-primary mb-2">
                Hubungi Kami
              </h3>
              <p className="text-foreground/80 font-body">
                +62 812-3456-7890<br />
                info@rumahkopioma.id
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-primary">
        <div className="container mx-auto text-center">
          <h2 className="font-display text-4xl font-bold text-primary-foreground mb-6">
            Siap Menikmati Kopi Terbaik?
          </h2>
          <p className="text-primary-foreground/90 text-lg mb-8 max-w-2xl mx-auto font-body">
            Kunjungi Rumah Kopi Oma hari ini dan rasakan kehangatan dalam setiap tegukan.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/scanner"
              className="inline-block bg-accent text-accent-foreground px-8 py-4 rounded-lg font-semibold text-lg hover:bg-accent/90 transition-colors"
            >
              Pesan Sekarang
            </Link>
            <Link
              to="/contact"
              className="inline-block bg-primary-foreground text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-primary-foreground/90 transition-colors"
            >
              Hubungi Kami
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Coffee className="w-6 h-6 text-primary" />
                <span className="font-display text-xl font-bold text-primary">Rumah Kopi Oma</span>
              </div>
              <p className="text-foreground/60 font-body text-sm leading-relaxed">Tempat kopi berkualitas dengan suasana hangat dan penuh kenangan.</p>
            </div>
            <div>
              <h4 className="font-display font-bold text-primary mb-3">Navigasi</h4>
              <div className="space-y-2">
                {[["Home","/"],["Menu","/menu"],["About","/about"],["Contact","/contact"]].map(([l,h])=>(
                  <Link key={l} to={h} className="block text-foreground/60 hover:text-primary text-sm font-body transition-colors">{l}</Link>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-display font-bold text-primary mb-3">Kontak</h4>
              <div className="space-y-2 text-sm font-body text-foreground/60">
                <p>📍 Jl. Subyek Merdeka No. 42</p>
                <p>📞 +62 812-3456-7890</p>
                <p>✉️ info@rumahkopioma.id</p>
                <p>🕐 Sen–Jum: 07.00–21.00</p>
              </div>
            </div>
          </div>
          <div className="border-t border-border pt-6 text-center text-foreground/50 text-sm font-body">
            © 2024 Rumah Kopi Oma. Semua hak dilindungi. Dibuat dengan ☕ dan cinta.
          </div>
        </div>
      </footer>
    </div>
  );
}
