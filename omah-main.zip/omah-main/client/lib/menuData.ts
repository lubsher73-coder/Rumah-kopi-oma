export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: "kopi" | "minuman" | "makanan";
  icon: string;
  available: boolean;
  popular?: boolean;
}

export const DEFAULT_MENU_ITEMS: MenuItem[] = [
  // Kopi
  {
    id: "1",
    name: "Espresso",
    description: "Kopi murni dengan cita rasa kaya dan pekat",
    price: 20000,
    category: "kopi",
    icon: "☕",
    available: true,
    popular: false,
  },
  {
    id: "2",
    name: "Americano",
    description: "Espresso dengan air panas, ringan namun berkarakter",
    price: 25000,
    category: "kopi",
    icon: "☕",
    available: true,
    popular: false,
  },
  {
    id: "3",
    name: "Cappuccino",
    description: "Espresso, steamed milk, dan foam yang sempurna",
    price: 35000,
    category: "kopi",
    icon: "🥛",
    available: true,
    popular: true,
  },
  {
    id: "4",
    name: "Caffe Latte",
    description: "Espresso dengan susu hangat dan sedikit foam lembut",
    price: 35000,
    category: "kopi",
    icon: "🥛",
    available: true,
    popular: true,
  },
  {
    id: "5",
    name: "Macchiato",
    description: "Espresso dengan sentuhan milk foam yang elegan",
    price: 30000,
    category: "kopi",
    icon: "☕",
    available: true,
    popular: false,
  },
  {
    id: "6",
    name: "Cold Brew",
    description: "Kopi dingin hasil seduhan 12 jam, segar dan menyegarkan",
    price: 32000,
    category: "kopi",
    icon: "🧊",
    available: true,
    popular: true,
  },
  {
    id: "7",
    name: "Vietnamese Drip",
    description: "Kopi tetes ala Vietnam dengan susu kental manis",
    price: 28000,
    category: "kopi",
    icon: "☕",
    available: true,
    popular: false,
  },
  {
    id: "8",
    name: "Flat White",
    description: "Espresso double shot dengan microfoam susu premium",
    price: 38000,
    category: "kopi",
    icon: "🥛",
    available: true,
    popular: false,
  },

  // Minuman Lainnya
  {
    id: "9",
    name: "Chocolate Latte",
    description: "Latte dengan cokelat Belgia premium yang kaya rasa",
    price: 40000,
    category: "minuman",
    icon: "🍫",
    available: true,
    popular: true,
  },
  {
    id: "10",
    name: "Matcha Latte",
    description: "Matcha Jepang grade premium dengan susu segar",
    price: 38000,
    category: "minuman",
    icon: "🍵",
    available: true,
    popular: true,
  },
  {
    id: "11",
    name: "Teh Tarik",
    description: "Teh susu tradisional yang creamy dan manis",
    price: 22000,
    category: "minuman",
    icon: "🧋",
    available: true,
    popular: false,
  },
  {
    id: "12",
    name: "Fresh Juice",
    description: "Jus buah segar pilihan – jeruk, manga, atau jambu",
    price: 28000,
    category: "minuman",
    icon: "🥤",
    available: true,
    popular: false,
  },
  {
    id: "13",
    name: "Iced Tea Lemon",
    description: "Teh dingin segar dengan perasan lemon asli",
    price: 18000,
    category: "minuman",
    icon: "🍋",
    available: true,
    popular: false,
  },
  {
    id: "14",
    name: "Strawberry Smoothie",
    description: "Smoothie stroberi segar blended dengan susu dan es",
    price: 35000,
    category: "minuman",
    icon: "🍓",
    available: true,
    popular: false,
  },

  // Makanan
  {
    id: "15",
    name: "Croissant Mentega",
    description: "Pastry renyah berlapis mentega Prancis asli",
    price: 25000,
    category: "makanan",
    icon: "🥐",
    available: true,
    popular: true,
  },
  {
    id: "16",
    name: "Roti Panggang Keju",
    description: "Toast dengan keju meleleh dan butter herb",
    price: 22000,
    category: "makanan",
    icon: "🍞",
    available: true,
    popular: false,
  },
  {
    id: "17",
    name: "Sandwich Ayam Panggang",
    description: "Roti ciabatta dengan ayam panggang, selada, dan mayo",
    price: 42000,
    category: "makanan",
    icon: "🥪",
    available: true,
    popular: false,
  },
  {
    id: "18",
    name: "Muffin Cokelat",
    description: "Muffin cokelat homemade yang lembut dan moist",
    price: 20000,
    category: "makanan",
    icon: "🧁",
    available: true,
    popular: false,
  },
  {
    id: "19",
    name: "Banana Cake",
    description: "Kue pisang rumahan yang manis dan legit",
    price: 28000,
    category: "makanan",
    icon: "🍌",
    available: true,
    popular: true,
  },
  {
    id: "20",
    name: "Waffle Original",
    description: "Waffle garing dengan sirup maple dan butter",
    price: 38000,
    category: "makanan",
    icon: "🧇",
    available: true,
    popular: false,
  },
];

const STORAGE_KEY = "rumahkopioma_menu";

export function getMenuItems(): MenuItem[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch {}
  return DEFAULT_MENU_ITEMS;
}

export function saveMenuItems(items: MenuItem[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}
